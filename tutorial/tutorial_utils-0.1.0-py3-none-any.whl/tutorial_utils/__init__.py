"""
tutorial_utils - a small, fun utility package for learning Python in the browser.

This package is designed to be loaded in Pyodide via micropip and demonstrates
a variety of Python capabilities: string manipulation, recursion, collections,
introspection, and simple ASCII visualisation.
"""

__version__ = "0.1.0"

import sys
import platform
from collections import Counter


# ── greeting ────────────────────────────────────────────────────────────────

def greet(name: str = "World") -> str:
    """Return a friendly greeting.

    >>> greet("Ada")
    'Hello, Ada! Welcome to Python in the browser.'
    """
    return f"Hello, {name}! Welcome to Python in the browser."


# ── fibonacci ───────────────────────────────────────────────────────────────

def fibonacci(n: int) -> list[int]:
    """Return the first *n* Fibonacci numbers.

    >>> fibonacci(8)
    [0, 1, 1, 2, 3, 5, 8, 13]
    """
    if n <= 0:
        return []
    if n == 1:
        return [0]
    seq = [0, 1]
    while len(seq) < n:
        seq.append(seq[-1] + seq[-2])
    return seq


# ── text analysis ───────────────────────────────────────────────────────────

def analyze_text(text: str) -> dict:
    """Analyse *text* and return a dictionary of statistics.

    Keys returned
    -------------
    char_count        : int   - total number of characters
    word_count        : int   - total number of whitespace-delimited words
    sentence_count    : int   - approximate number of sentences (. ! ?)
    unique_words      : int   - number of distinct lower-cased words
    average_word_length : float - mean word length (0.0 for empty text)
    most_common_words : list[tuple[str, int]] - top-5 most frequent words

    >>> stats = analyze_text("Hello hello world")
    >>> stats["word_count"]
    3
    >>> stats["unique_words"]
    2
    """
    words = text.split()
    lower_words = [w.strip(".,!?;:\"'()[]{}").lower() for w in words]
    lower_words = [w for w in lower_words if w]  # drop empties

    word_count = len(words)
    char_count = len(text)
    sentence_count = sum(text.count(ch) for ch in ".!?") or (1 if text.strip() else 0)
    unique_words = len(set(lower_words))
    avg_len = sum(len(w) for w in lower_words) / len(lower_words) if lower_words else 0.0
    most_common = Counter(lower_words).most_common(5)

    return {
        "char_count": char_count,
        "word_count": word_count,
        "sentence_count": sentence_count,
        "unique_words": unique_words,
        "average_word_length": round(avg_len, 2),
        "most_common_words": most_common,
    }


# ── ASCII bar chart ─────────────────────────────────────────────────────────

def plot_ascii(data: dict, title: str = "Bar Chart", bar_char: str = "█", width: int = 40) -> str:
    """Return a simple ASCII horizontal bar chart.

    Parameters
    ----------
    data      : dict mapping label -> numeric value
    title     : chart title
    bar_char  : character used for bars (default full-block)
    width     : maximum bar width in characters

    >>> print(plot_ascii({"A": 3, "B": 7, "C": 5}))  # doctest: +SKIP
    """
    if not data:
        return "(no data)"

    max_val = max(data.values())
    max_label = max(len(str(k)) for k in data)
    scale = width / max_val if max_val else 1

    lines = []
    lines.append(f"  {title}")
    lines.append(f"  {'─' * (max_label + width + 6)}")
    for label, value in data.items():
        bar_len = int(value * scale)
        bar = bar_char * bar_len
        lines.append(f"  {str(label):>{max_label}} | {bar} {value}")
    lines.append(f"  {'─' * (max_label + width + 6)}")

    return "\n".join(lines)


# ── system info ─────────────────────────────────────────────────────────────

def system_info() -> dict:
    """Return information about the current Python runtime.

    Useful for verifying that code is running inside Pyodide / WASM.
    """
    info = {
        "python_version": platform.python_version(),
        "platform": platform.platform(),
        "machine": platform.machine(),
        "implementation": platform.python_implementation(),
        "sys_platform": sys.platform,
        "is_wasm": sys.platform == "emscripten",
        "maxsize": sys.maxsize,
        "byteorder": sys.byteorder,
        "modules_loaded": len(sys.modules),
    }
    return info


# ── quick demo ──────────────────────────────────────────────────────────────

def demo() -> str:
    """Run a short demonstration of every function and return the output."""
    parts = []
    parts.append(greet("Learner"))
    parts.append("")
    parts.append(f"Fibonacci(10): {fibonacci(10)}")
    parts.append("")
    sample = "The quick brown fox jumps over the lazy dog. The dog barked!"
    stats = analyze_text(sample)
    parts.append(f"Text analysis of: \"{sample}\"")
    for k, v in stats.items():
        parts.append(f"  {k}: {v}")
    parts.append("")
    chart_data = {"Python": 95, "JS": 80, "Rust": 70, "Go": 60}
    parts.append(plot_ascii(chart_data, title="Language Popularity"))
    parts.append("")
    si = system_info()
    parts.append("System info:")
    for k, v in si.items():
        parts.append(f"  {k}: {v}")
    return "\n".join(parts)
